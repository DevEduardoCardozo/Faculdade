public class Contador {
    private int valor = 0;
    
    public void Incrementar(){
        valor++;
    }
    
    public void Decrementar(){
        valor--;
    }
    
    public void MostrarValor(){
        System.out.print("Valor atual: " + valor);
    }
}