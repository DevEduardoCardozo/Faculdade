import java.util.Scanner;

public class PrincipalCaixaEletronico{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        CaixaEletronico caixa = new CaixaEletronico();
        
        int opcao;
        
        do {
            System.out.println("1 - Depositar");
            System.out.println("2 - Sacar");
            System.out.println("3 - Mostrar saldo");
            System.out.println("4 - Sair");
            System.out.println("Escolha uma opção: ");
            opcao = sc.nextInt();
            
            if (opcao == 1){
                System.out.println("Valor para depositar: ");
                double valor =sc.nextDouble();
                caixa.Depositar(valor);
            }
            else if (opcao == 2){
                System.out.println("Valor para sacar: ");
                double valor = sc.nextDouble();
                caixa.Sacar(valor);
            } else if (opcao == 3){
                caixa.MostrarSaldo();
            }
        } while (opcao != 4);
        
        sc.close();
    }
}