import java.util.Scanner;

public class PrincipalPessoa {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite o nome da pessoa: ");
        String nome = sc.nextLine();
        
        System.out.println("Digite a idade da pessoa: ");
        int idade = sc.nextInt();
        
        Pessoa pessoa = new Pessoa(nome, idade);
        
        if (pessoa.MaiorIdade()){
            System.out.println(nome + " É maior de idade.");
        }
        else {
            System.out.println(nome + " não é maior de idade.");
        }
    }
}