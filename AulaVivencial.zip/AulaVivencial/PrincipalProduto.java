import java.util.Scanner;

public class PrincipalProduto
{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite o nome do produto: ");
        String nome = sc.nextLine();
        
        System.out.println("Digite o preço do produto: ");
        double preco = sc.nextDouble();
        
        Produto produto = new Produto(nome, preco);
        
        System.out.println("Produto cadastrado: ");
        System.out.print("");
        System.out.println("Nome: " + produto.getNome());
        System.out.print("");
        System.out.println("Preço: " + produto.getPreco());
        
        sc.close();
    }
}
