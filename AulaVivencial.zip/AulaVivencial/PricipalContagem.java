import java.util.Scanner;

public class PricipalContagem {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite um número positivo: ");
        int numero = sc.nextInt();
        
        if (numero >= 0){
            Contagem contagem = new Contagem();
            contagem.Contar(numero);
        }
        else {
            System.out.println("Número inválido!");
        }
    }
}