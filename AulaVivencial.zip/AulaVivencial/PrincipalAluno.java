import java.util.Scanner;

public class PrincipalAluno{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite o nome do aluno: ");
        String nome = sc.nextLine();
        
        System.out.println("Digite a primeira nota do aluno: ");
        double nota1 = sc.nextDouble();
        
        System.out.println("Digite a segunda nota do aluno: ");
        double nota2 = sc.nextDouble();
        
        Aluno aluno = new Aluno(nome, nota1, nota2);
        
        System.out.println("Média do aluno: " + aluno.CalcularMedia());
        System.out.println("Situação do aluno: " + aluno.Situacao());
    }
}