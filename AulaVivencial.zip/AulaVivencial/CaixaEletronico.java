public class CaixaEletronico{
    private double saldo = 0;
    
    public void Sacar(double valor){
        if (valor <= getSaldo()){
            setSaldo(getSaldo() - valor);
            System.out.println("Saque de " + valor + " realizado!");
        }
        else {
            System.out.println("Saldo insuficiente!");
        }
    }
    
    public void Depositar(double valor){
        setSaldo(getSaldo() + valor);
        System.out.println("Depósito de " + valor + " realizado!");
    }
    
    public void MostrarSaldo(){
        System.out.println("Saldo atual: R$" + getSaldo());
    }
    
    public double getSaldo(){
        return saldo;
    }
    
    public void setSaldo(double saldo){
        this.saldo = saldo;
    }
}