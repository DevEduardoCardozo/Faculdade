import java.util.Scanner;

public class PrincipalContador{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        Contador contador = new Contador();
        
        int opcao;
        
        do {
            System.out.println("1 - Incrementar");
            System.out.println("2 - Decrementar");
            System.out.println("3 - Mostrar valor");
            System.out.println("4 - Sair");
            System.out.println("Escolha uma opção");
            opcao = sc.nextInt();
            
            if (opcao == 1){
                contador.Incrementar();
            } else if (opcao == 2) {
                contador.Decrementar();
            } else if (opcao == 3){
                contador.MostrarValor();
            }
        } while (opcao != 4);
        
        sc.close();
    }
}