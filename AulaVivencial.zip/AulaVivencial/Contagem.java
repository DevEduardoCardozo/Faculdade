public class Contagem{
    public void Contar(int numero){
        for(int i = numero; i > 0; i--){
            System.out.println(i);
        }
    }
}