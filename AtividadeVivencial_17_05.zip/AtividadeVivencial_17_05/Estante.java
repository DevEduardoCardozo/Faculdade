public class Estante {
    private String nome;
    private Livro[] livros;

    public Estante() {
        this.nome = "Estante da Biblioteca";
        livros = new Livro[3];
    }

    public Estante(String nome) {
        this.nome = nome;
        livros = new Livro[3];
    }

    public Estante(String nome, Livro l1, Livro l2, Livro l3) {
        this.nome = nome;
        livros = new Livro[] {l1, l2, l3};
    }

    public boolean insereLivro(Livro livro) {
        for (int i = 0; i < livros.length; i++) {
            if (livros[i] != null && 
                livros[i].getTitulo().equals(livro.getTitulo()) && 
                livros[i].getAutor().equals(livro.getAutor())) {
                return false;
            }
        }
        for (int i = 0; i < livros.length; i++) {
            if (livros[i] == null) {
                livros[i] = livro;
                return true;
            }
        }
        return false;
    }

    public boolean verificaLivro(String titulo) {
        for (Livro livro : livros) {
            if (livro != null && livro.getTitulo().equals(titulo)) {
                return true;
            }
        }
        return false;
    }

    public void imprimeLivroPorAno() {
        Livro[] copia = livros.clone();
        for (int i = 0; i < copia.length - 1; i++) {
            for (int j = i + 1; j < copia.length; j++) {
                if (copia[i] != null && copia[j] != null && copia[i].getAno() < copia[j].getAno()) {
                    Livro aux = copia[i];
                    copia[i] = copia[j];
                    copia[j] = aux;
                }
            }
        }
        for (Livro livro : copia) {
            if (livro != null) {
                System.out.println(livro);
            }
        }
    }

    public double calculaMediaPreco() {
        double soma = 0;
        int count = 0;
        for (Livro livro : livros) {
            if (livro != null) {
                soma += livro.getPreco();
                count++;
            }
        }
        return count > 0 ? soma / count : 0;
    }

    public void livrosRaros() {
        for (Livro livro : livros) {
            if (livro != null && livro.isRaro()) {
                System.out.println(livro);
            }
        }
    }

    public boolean removeLivro(String titulo, String autor) {
        for (int i = 0; i < livros.length; i++) {
            if (livros[i] != null && livros[i].getTitulo().equals(titulo) && livros[i].getAutor().equals(autor)) {
                livros[i] = null;
                return true;
            }
        }
        return false;
    }
}