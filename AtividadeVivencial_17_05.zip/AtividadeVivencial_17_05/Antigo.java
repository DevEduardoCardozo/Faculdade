public class Antigo extends Livro {
    private int numeroEdicao;

    public Antigo(String titulo, String autor, double preco, int ano, boolean raro, int numeroEdicao) {
        super(titulo, autor, preco, ano, raro);
        this.numeroEdicao = numeroEdicao;
    }

    public int getNumeroEdicao() { return numeroEdicao; }
    public void setNumeroEdicao(int numeroEdicao) { this.numeroEdicao = numeroEdicao; }

    public String toString() {
        return super.toString() + " | Edição: " + numeroEdicao;
    }
}