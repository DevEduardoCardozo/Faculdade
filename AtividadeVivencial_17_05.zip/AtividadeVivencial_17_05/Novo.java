public class Novo extends Livro {
    private double desconto;

    public Novo(String titulo, String autor, double preco, int ano, boolean raro, double desconto) {
        super(titulo, autor, preco, ano, raro);
        this.desconto = desconto;
    }

    public double getDesconto() { return desconto; }
    public void setDesconto(double desconto) { this.desconto = desconto; }

    public String toString() {
        return super.toString() + " | Desconto: " + desconto + "%";
    }
}