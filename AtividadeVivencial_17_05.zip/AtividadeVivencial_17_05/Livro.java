public class Livro{
    private String titulo;
    private String autor;
    private double preco;
    private int ano;
    private boolean raro;
    
    public Livro(String titulo, String autor, double preco, int ano, boolean raro){
        this.titulo = titulo;
        this.autor = autor;
        this.preco = preco;
        this.ano = ano;
        this.raro = raro;
    }
      //Métodos de acesso
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public double getPreco() { return preco; }
    public int getAno() { return ano; }
    public boolean isRaro() { return raro; }

    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setAutor(String autor) { this.autor = autor; }
    public void setPreco(double preco) { this.preco = preco; }
    public void setAno(int ano) { this.ano = ano; }
    public void setRaro(boolean raro) { this.raro = raro; }

    public String toString() {
        return titulo + " | Autor: " + autor + " | Ano: " + ano + " | Preço: R$ " + preco + " | Raro: " + raro;
    }
}