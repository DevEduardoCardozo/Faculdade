import java.util.Random;

public class Principal {
    public static void main(String[] args) {
        Random rand = new Random();
        Estante estante = new Estante("Estante da Biblioteca");

        String[] titulos = {"1984", "Dom Casmurro", "Harry Potter", "O Pequeno Príncipe", "O Senhor dos Anéis"};
        String[] autores = {"George Orwell", "Machado de Assis", "J.K. Rowling", "Antoine de Saint-Exupéry", "J.R.R. Tolkien"};
        double[] precos = {45.0, 30.0, 79.90, 49.90, 14,90};
        int[] anos = {1949, 1899, 1997, 1943, 1954};
        
        for (int i = 0; i < 3; i++) {
            String titulo = titulos[i];
            String autor = autores[i];
            double preco = precos[i];
            int ano = anos[i];
            boolean raro = rand.nextBoolean();

            if (rand.nextBoolean()) {
                int edicao = 1 + rand.nextInt(5);
                estante.insereLivro(new Antigo(titulo, autor, preco, ano, raro, edicao));
            } else {
                double desconto = rand.nextInt(30);
                estante.insereLivro(new Novo(titulo, autor, preco, ano, raro, desconto));
            }
        }

        System.out.println("\n--- Verificando livro '1984' ---");
        System.out.println("Existe? " + estante.verificaLivro("1984"));

        System.out.println("\n--- Livros por ano (decrescente) ---");
        estante.imprimeLivroPorAno();

        System.out.println("\n--- Média de preços ---");
        System.out.println("Média: R$" + estante.calculaMediaPreco());

        System.out.println("\n--- Livros raros ---");
        estante.livrosRaros();

        System.out.println("\n--- Removendo Dom Casmurro ---");
        boolean removido = estante.removeLivro("Dom Casmurro", "Machado de Assis");
        System.out.println("Removido? " + removido);
    }
}